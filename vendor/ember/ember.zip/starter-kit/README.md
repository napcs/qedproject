*Don't clone this repo, download instead!*

[https://github.com/amberjs/starter-kit/downloads]
